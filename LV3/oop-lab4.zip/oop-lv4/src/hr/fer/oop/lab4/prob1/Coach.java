package hr.fer.oop.lab4.prob1;
import java.util.function.Predicate;

import hr.fer.oop.lab4.prob2.IManageableTeam;
import hr.fer.oop.lab4.prob2.NotEligiblePlayerException;
import hr.fer.oop.lab4.prob3.*;
/**
 * 
 * @author Matej Bogomolec
 *
 */
public class Coach extends Person implements IManager
{
	/**
	 * 
	 */
	private int coachingSkill;
	private Formation favoriteFormation;
	private final int MIN_SKILL = 0;
	private final int MAX_SKILL = 100;
	private IManageableTeam managingTeam;
	/**
	 * 
	 * @param name
	 * @param country
	 * @param emotion
	 * @param coachingSkill
	 * @param formation
	 */
	public Coach (String name, String country, int emotion, int coachingSkill, 
			Formation formation)
	{
		super (name,country,emotion);
		if (coachingSkill < MIN_SKILL || coachingSkill > 100) throw new IllegalArgumentException("Coachers Skill "
				+ "value must be in interval [" + MIN_SKILL + "," + MAX_SKILL + "], not:" + coachingSkill);
		this.coachingSkill = coachingSkill;
		this.favoriteFormation = formation;
	}
	/**
	 * 
	 * @return
	 */
	public int getCoachingSkill()
	{
		return coachingSkill;
	}
	/**
	 * 
	 * @param coachingSkill
	 */
	public void setCoachingSkill (int coachingSkill)
	{
		this.coachingSkill = coachingSkill;
	}
	/**
	 * 
	 * @return
	 */
	public Formation getFavoriteFormation()
	{
		return favoriteFormation;
	}
	/**
	 * 
	 * @param formation
	 */
	public void setFavoriteFormation(Formation formation)
	{
		this.favoriteFormation = formation;
	}
	public void registerPlayers(Iterable<FootballPlayer> offeredPlayers, Predicate<FootballPlayer> criteria) throws UnemployedCoachException
	{
		if (managingTeam == null) throw  new UnemployedCoachException("Coach" + super.getName()+ "is unemployed.");
		for(FootballPlayer player : offeredPlayers)
		{
			if(criteria.test(player)) 
			{
				try
				{
					managingTeam.registerPlayer(player);
				}
				catch (NotEligiblePlayerException e)
				{
					System.out.println("Gre�ka: " + e.toString() +"\nOporavak ");
				}
			}

		}
		
	}
	public void pickStartingEleven(Predicate<FootballPlayer> criteria) throws UnemployedCoachException
	{
		if (managingTeam == null) throw  new UnemployedCoachException("Coach" + super.getName()+ "is unemployed.");
		for(FootballPlayer player : managingTeam.getRegisteredPlayers())
		{
			if(criteria.test(player))
			{
				try 
				{
					managingTeam.addPlayerToStartingEleven(player);
				} 
				catch (NotEligiblePlayerException e) 
				{
					System.out.println("Gre�ka: " + e.toString() +"\nOporavak ");
				}
			}
		}
	}
	public void forceMyFormation() throws UnemployedCoachException
	{
		if (managingTeam == null) throw  new UnemployedCoachException("Coach" + super.getName()+ "is unemployed.");
		managingTeam.setFormation(favoriteFormation);
		managingTeam.clearStartingEleven();
	}
	public void setManagingTeam(IManageableTeam team)
	{
		this.managingTeam = team;
	}
	public IManageableTeam getManagingTeam()
	{
		return managingTeam;
	}
}
