package hr.fer.oop.lab4.prob1;
/**
 * 
 * @author Matej Bogomolec
 *
 */
public class FootballPlayer extends Person
{
	/**
	 * 
	 */
	private int playingSkill;
	private PlayingPosition playingPosition;
	public final static int MIN_PLAYING_SKILL = 0;
	public final static int MAX_PLAYING_SKILL = 100;
	/**
	 * 
	 * @param name
	 * @param country
	 * @param emotion
	 * @param playingSkill
	 */
	public FootballPlayer(String name, String country, int emotion, int playingSkill,
			PlayingPosition playingPosition)
	{
		super (name,country,emotion);
		if (playingSkill < MIN_PLAYING_SKILL || playingSkill > MAX_PLAYING_SKILL) throw new IllegalArgumentException("Players Skill "
				+ "value must be in interval [" + MIN_PLAYING_SKILL + "," + MAX_PLAYING_SKILL + "], not:" + playingSkill);
		this.playingSkill = playingSkill;
		this.playingPosition = playingPosition;
	}
	/**
	 * 
	 * @return
	 */
	public int getPlayingSkill()
	{
		return playingSkill;
	}
	/**
	 * 
	 * @param playingSkill
	 */
	public void setPlayingSkill(int playingSkill)
	{
		this.playingSkill=playingSkill;
	}
	/**
	 * 
	 * @return
	 */
	public PlayingPosition getPlayingPosition()
	{
		return playingPosition;
	}
	/**
	 * 
	 * @param playingPosition
	 */
	public void setPlayingPosition(PlayingPosition playingPosition)
	{
		this.playingPosition = playingPosition;
	}
}
