package hr.fer.oop.lab4.prob1;
/**
 * 
 * @author Matej
 *
 */
public enum PlayingPosition 
{
	FW, MF, DF, GK;
}
