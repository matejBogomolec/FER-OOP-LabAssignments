package hr.fer.oop.lab4.prob3;

public class UnemployedCoachException extends Exception
{
	public UnemployedCoachException (String message)
	{
		super(message);
	}
}

