package hr.fer.oop.lab4.prob4;

import hr.fer.oop.lab4.prob2.IMatchInspectableTeam;
import java.math.*;

public class Match implements IPlayableMatch
{
	private final IMatchInspectableTeam home;
	private final IMatchInspectableTeam away;
	private final MatchType type;
	private MatchOutcome outcome = MatchOutcome.NOT_AVAILABLE;
	Match(IMatchInspectableTeam home, IMatchInspectableTeam away, MatchType type)
	{
		this.home = home;
		this.away = away;
		this.type = type;
	}
	@Override
	public void play () throws NotPlayableMatchException
	{
		if((home == null || away == null)) throw new NotPlayableMatchException("One of the teams are not set.");
		if(!home.isMatchReady() || !away.isMatchReady()) throw new NotPlayableMatchException("One of the teams are not ready.");
		if(home.equals(away)) throw new NotPlayableMatchException("Both teams are the same.");
		double h, a, rng;
		rng = Math.random();
		h = (home.calculateRating()) / (home.calculateRating() + away.calculateRating());
		a = (away.calculateRating()) / (home.calculateRating() + away.calculateRating());
		if(rng < h - (Math.min(a, h)/2.)) outcome = MatchOutcome.HOME_WIN;
		else if (rng > h + (Math.min(a, h)/2.)) outcome = MatchOutcome.AWAY_WIN;
		else outcome = MatchOutcome.DRAW;
		
	}
	public IMatchInspectableTeam getHome()
	{
		return home;
	}
	public IMatchInspectableTeam getAway()
	{
		return away;
	}
	public MatchType getType()
	{
		return type;
	}
	public MatchOutcome getOutcome()
	{
		return outcome;
	}
}
