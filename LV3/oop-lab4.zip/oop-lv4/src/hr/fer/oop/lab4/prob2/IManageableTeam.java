package hr.fer.oop.lab4.prob2;

import java.util.Collection;
import java.util.function.Predicate;

import hr.fer.oop.lab4.prob1.*;

public interface IManageableTeam 
{

	public void registerPlayer(FootballPlayer player) throws NotEligiblePlayerException;
	public void unregisterPlayer(FootballPlayer player) throws IllegalArgumentException;
	public void clearStartingEleven();
	public void addPlayerToStartingEleven(FootballPlayer player) throws NotEligiblePlayerException;
	public void removePlayerFromStartingEleven(FootballPlayer player) throws IllegalArgumentException;
	public void setFormation(Formation formation);
	public Formation getFormation();
	public Collection<FootballPlayer> getRegisteredPlayers();
	public Collection<FootballPlayer> getStartingEleven();
	public boolean isPlayerRegistrable(FootballPlayer player);
	public Collection<FootballPlayer> filterRegisteredPlayers(Predicate<FootballPlayer> criteria);
}
