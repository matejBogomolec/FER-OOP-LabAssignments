package hr.fer.oop.lab4.prob2;

public class NotEligiblePlayerException extends Exception
{
	public NotEligiblePlayerException (String message)
	{
		super(message);
	}
}
