package hr.fer.oop.lab4.prob4;

public interface IPlayableMatch 
{
	public void play() throws NotPlayableMatchException;
}
