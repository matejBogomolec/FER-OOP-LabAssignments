package hr.fer.oop.lab4.prob1;

public enum Formation 
{
	F442, F352, F541;
}
