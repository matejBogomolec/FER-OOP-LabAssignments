package hr.fer.oop.lab4.prob4;

public enum MatchType 
{
	FRIENDLY, COMPETITIVE;
}
