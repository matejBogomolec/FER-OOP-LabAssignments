package hr.fer.oop.lab4.prob3;

import java.util.function.Predicate;
import hr.fer.oop.lab4.prob1.FootballPlayer;
import hr.fer.oop.lab4.prob2.IManageableTeam;



public interface IManager
{
	public void registerPlayers(Iterable<FootballPlayer> offeredPlayers, Predicate<FootballPlayer> criteria) throws UnemployedCoachException;
	public void pickStartingEleven(Predicate<FootballPlayer> criteria) throws UnemployedCoachException;
	public void forceMyFormation() throws UnemployedCoachException;
	public void setManagingTeam(IManageableTeam team);
	
}
