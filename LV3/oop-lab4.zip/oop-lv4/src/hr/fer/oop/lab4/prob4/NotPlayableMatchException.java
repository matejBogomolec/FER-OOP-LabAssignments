package hr.fer.oop.lab4.prob4;

public class NotPlayableMatchException extends Exception 
{
	public NotPlayableMatchException (String message)
	{
		super(message);
	}
}
