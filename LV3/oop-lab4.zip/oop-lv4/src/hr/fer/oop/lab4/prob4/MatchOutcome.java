package hr.fer.oop.lab4.prob4;

public enum MatchOutcome 
{
	NOT_AVAILABLE, HOME_WIN, AWAY_WIN, DRAW;
}
