package hr.fer.oop.lab4.prob2;

public interface IMatchInspectableTeam 
{
	public boolean isMatchReady();
	public int calculateTeamSpirit();
	public int calculateTeamSkill();
	public double calculateRating();
}
