package hr.fer.oop.lab3.prob3;

import java.util.Iterator;


public class SimpleHashtable<K, V> implements Iterable<SimpleHashtable.TableEntry<K, V>>{
	private int size;
	private TableEntry<K, V>[] table;
	public SimpleHashtable()
	{ 
		size=16;
		table = (TableEntry<K, V>[]) new TableEntry[size];
	}
	public SimpleHashtable(int capacity)

	{
		if(capacity<1)
		{
			System.err.println("Invalid size for table!");
		}
		else
		{
			int exp=(int)Math.floor(Math.sqrt(capacity));
			size = (int) Math.pow(2, exp);
			table = (TableEntry<K, V>[]) new TableEntry[size];	
		}
		
	}
	public void put(K key, V value){
		int index = Math.abs(key.hashCode()) % 2;
		TableEntry<K, V> pointer=table[index];
		if(pointer==null)
		{
			TableEntry<K, V> Entry=new TableEntry<K, V>(key,value,null);
			table[index]=Entry;
		}
		else
		{
			while(pointer!=null)
			{
				if(pointer.next==null)
				{
					TableEntry<K,V> Entry=new TableEntry<K, V>(key,value,null);
					pointer.next=Entry;
					break;
				}
				if(pointer.getKey() == key)
				{
					pointer.setValue(value);
					break;
				}
				pointer=pointer.next;
			}
		}
	}
	public V get(K key){
		int index=Math.abs(key.hashCode())%size;
		TableEntry<K, V> pointer=table[index];
		while(pointer!=null){
			if(pointer.getKey().equals(key)){
				return pointer.getValue();
			}
			pointer=pointer.next;
		}
		return null;
	}
	public int size()
	{
		int n=0;
		for(int i=0; i < size; i++)
		{
			TableEntry<K, V> pointer=table[i];
			while(pointer != null)
			{
				n++;
				pointer=pointer.next;	
			}
		}
		return n;
	}
	public boolean containsKey(K key)
	{
		for(int i=0;i<size;i++)
		{
			TableEntry<K, V> pointer=table[i];
			while(pointer!=null){
				if(pointer.getKey() == key)
				{
					return true;
				}
				pointer=pointer.next;
			}
		}
		return false;
	}
	public boolean containsValue(V value)
	{
		for(int i=0;i<size;i++)
		{
			TableEntry<K, V> pointer=table[i];
			while(pointer!=null){
				if(pointer.getValue() == value)
				{
					return true;
				}
				pointer=pointer.next;
			}
		}
		return false;
	}
	public void remove (K key)
	{
		
	}
	public boolean isEmpty(V value)
	{
		for(int i=0; i<= size; i++)
		{
			if (table[i]!=null) return false;
		}
		return true;
	}
	@Override
	public String toString()
	{
		StringBuilder string = new StringBuilder();
		for(int i=0;i<size;i++){
			TableEntry<K, V> pointer=table[i];
			while(pointer!=null){
				string.append(pointer.toString());
				pointer=pointer.next;
			}
			string.append('\n');
		}
		return string.toString();
	}
	public static class TableEntry<K,V>
	

	{
		private K key;
		private V value;
		protected TableEntry<K, V> next;
		TableEntry (K key, V value, TableEntry<K,V> next)
		{
			this.key = key;
			this.value = value;
			this.next = next;
		}
		public K getKey()
		{
			return key;
		}
		public V getValue()
		{
			return value;
		}
		public void setValue(V new_value)
		{
			value = new_value;
		}
		@Override
		public String toString()
		{
			StringBuilder string=new StringBuilder();
			string.append(" { ");
			string.append(key.toString());
			string.append(" = ");
			string.append(value.toString());
			string.append(" } ");
			return string.toString();
		}
		public class IterableEntry implements Iterator<TableEntry<K, V>> {
		int index;
		TableEntry<K, V> currentEntry;

		public IterableEntry() {
			index = -1;
			currentEntry = null;
		}

		private void nextIndex() {
			index++;
			if (index >= table.length) {
				return;
			}
			currentEntry = table[index];
		}

		@Override
		public boolean hasNext() {
			if (index > table.length) {
				return false;
			}
			if (currentEntry == null) {
				nextIndex();
				return this.hasNext();
			}
			return true;
		}

		@Override
		public TableEntry<K, V> next() {
			if (currentEntry == null) {
				nextIndex();
				return next();
			}

			TableEntry<K, V> output = currentEntry;
			currentEntry = currentEntry.next;

			return output;
		}
	}
	}
	public Iterator<TableEntry<K, V>> iterator() 
	{
		return new IterableEntry();
	}

	public static  void main(String args[])
	{
		// create collection:
		SimpleHashtable<String,Integer> examMarks = new SimpleHashtable<>(2);
		// fill data:
		examMarks.put("Ivana", Integer.valueOf(2));
		examMarks.put("Ante", Integer.valueOf(2));
		examMarks.put("Jasna", Integer.valueOf(2));
		examMarks.put("Kristina", Integer.valueOf(5));
		examMarks.put("Ivana", Integer.valueOf(5)); // overwrites old grade for Ivana
		System.out.println("Prvi obilazak stala");
		for(SimpleHashtable.TableEntry<String,Integer> entry : examMarks)
		{
			System.out.printf("%s => %s%n", entry.getKey(), entry.getValue());
		}
		System.out.println("Drugi obilazak stala");
		for(SimpleHashtable.TableEntry<String,Integer> entry : examMarks)
		{
			System.out.printf("%s => %s%n", entry.getKey(), entry.getValue());
		}
		
	}
}

